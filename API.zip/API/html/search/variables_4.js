var searchData=
[
  ['data_5011',['data',['../structacc__cal__result__t.html#a6d6f68b375da17fb747a9704e08f7836',1,'acc_cal_result_t::data()'],['../structSPI__RegType.html#a89b8ae284d9a7b08778c1b1b1996bd15',1,'SPI_RegType::DATA()']]],
  ['data_5favailable_5012',['data_available',['../acc__exploration__server_8c.html#adec1ff4e3c4cdeb15cc6b956b395bb1b',1,'acc_exploration_server.c']]],
  ['data_5flength_5013',['data_length',['../structacc__processing__helper__subsweep__info__t.html#a11bf710d54f13b1866721631f3abfb66',1,'acc_processing_helper_subsweep_info_t']]],
  ['data_5foffset_5014',['data_offset',['../structacc__processing__helper__subsweep__info__t.html#a3ce12b8d92d6212ddfa9d387b26c2d2b',1,'acc_processing_helper_subsweep_info_t']]],
  ['data_5fsaturated_5015',['data_saturated',['../structacc__processing__iq__result__t.html#a36a8fde06bd8174c1d25719d507a8810',1,'acc_processing_iq_result_t']]],
  ['dbg_5fen_5016',['DBG_EN',['../structio__matrix__registers__t.html#a032636f94944ba785721d1ef50486e0e',1,'io_matrix_registers_t']]],
  ['debug_5fuart_5fhandle_5017',['debug_uart_handle',['../acc__exploration__server_8c.html#a1b054bccf735183f72bcccfbb2a4116e',1,'debug_uart_handle():&#160;acc_exploration_server.c'],['../example__rtc__wakeup_8c.html#a1b054bccf735183f72bcccfbb2a4116e',1,'debug_uart_handle():&#160;example_rtc_wakeup.c'],['../aps__uart_8h.html#a1b054bccf735183f72bcccfbb2a4116e',1,'debug_uart_handle():&#160;acc_exploration_server.c'],['../acc__platform__aps_8c.html#a1b054bccf735183f72bcccfbb2a4116e',1,'debug_uart_handle():&#160;acc_platform_aps.c']]],
  ['diag_5018',['diag',['../structacc__covariance__matrix__t.html#a55ea6c4e99a69992d1887452d87c9fd5',1,'acc_covariance_matrix_t']]],
  ['directio_5019',['DIRECTIO',['../structSPI__RegType.html#a9375aac1f014abd9bdb42b3fa50cc763',1,'SPI_RegType']]],
  ['dma_5frx_5fchannel_5020',['dma_rx_channel',['../struct____spi__slave__handle__typedef.html#a64a4f7bbeddb0c21bd04b12c1a135583',1,'__spi_slave_handle_typedef']]],
  ['dma_5ftx_5fchannel_5021',['dma_tx_channel',['../struct____spi__slave__handle__typedef.html#a8c987837c60bac88cd6cc13fcf148529',1,'__spi_slave_handle_typedef::dma_tx_channel()'],['../struct____uart__handle__typedef.html#a96c1114f06cc347c0e185de692f4f855',1,'__uart_handle_typedef::dma_tx_channel()']]],
  ['dmacfg_5022',['DMACFG',['../structDMA__RegType.html#a80db8de70fce405696df86edef8f574a',1,'DMA_RegType']]],
  ['dmactrl_5023',['DMACTRL',['../structDMA__RegType.html#ad7a8b526fd2afbb6d63c194765964d93',1,'DMA_RegType']]],
  ['dstaddrh_5024',['DSTADDRH',['../structDMA__CHANNEL__RegType.html#a13a4da624f980d5396ee158b508c65f6',1,'DMA_CHANNEL_RegType']]],
  ['dstaddrl_5025',['DSTADDRL',['../structDMA__CHANNEL__RegType.html#afe5aea6e55f64029350d3099a6f593d5',1,'DMA_CHANNEL_RegType']]]
];
