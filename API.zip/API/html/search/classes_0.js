var searchData=
[
  ['_5f_5fspi_5fslave_5fhandle_5ftypedef_4295',['__spi_slave_handle_typedef',['../struct____spi__slave__handle__typedef.html',1,'']]],
  ['_5f_5fuart_5fhandle_5ftypedef_4296',['__uart_handle_typedef',['../struct____uart__handle__typedef.html',1,'']]]
];
