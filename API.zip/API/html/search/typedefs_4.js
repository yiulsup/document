var searchData=
[
  ['set_5fbaudrate_5ffunction_5ft_5316',['set_baudrate_function_t',['../acc__exploration__server__base_8h.html#ad2421e2861e16b00682ae58619f6c672',1,'acc_exploration_server_base.h']]],
  ['spi_5fslave_5fhandle_5ftypedef_5ft_5317',['spi_slave_handle_typedef_t',['../aps__spi__slave_8h.html#af6c8968f6c7945615e4fac487c1c0a4d',1,'aps_spi_slave.h']]]
];
