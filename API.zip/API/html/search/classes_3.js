var searchData=
[
  ['dma_5fchannel_5fregtype_4327',['DMA_CHANNEL_RegType',['../structDMA__CHANNEL__RegType.html',1,'']]],
  ['dma_5fregtype_4328',['DMA_RegType',['../structDMA__RegType.html',1,'']]]
];
