var searchData=
[
  ['fea_5fen_1363',['FEA_EN',['../structPLIC__RegType.html#a313601b2d7fc56b4ec3a0f1b45bbc7bc',1,'PLIC_RegType']]],
  ['float32_5ft_1364',['float32_t',['../group__definitions.html#ga4611b605e45ab401f02cab15c5e38715',1,'acc_definitions.h']]],
  ['frame_1365',['frame',['../structacc__processing__iq__result__t.html#a0298cd9f1b2003d14c4640991ea69bbb',1,'acc_processing_iq_result_t']]],
  ['frame_5fidx_1366',['frame_idx',['../structacc__covariance__matrix__info__t.html#a31499fb18b5ac48c1ef488745c71d8df',1,'acc_covariance_matrix_info_t::frame_idx()'],['../structacc__time__filter__info__t.html#a48979bc2cac6e1f9bef40ad7dfc64f2e',1,'acc_time_filter_info_t::frame_idx()']]]
];
