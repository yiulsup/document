var searchData=
[
  ['_5f_5fheapbase_4958',['__HeapBase',['../syscalls_8c.html#a0d316bd4ef5a593400435781c6c68b1c',1,'syscalls.c']]],
  ['_5f_5fheaplimit_4959',['__HeapLimit',['../syscalls_8c.html#a4ee99e498d365d260fd876fab3a347c1',1,'syscalls.c']]],
  ['_5fstart_4960',['_start',['../example__rtc__wakeup_8c.html#aaae9c5608af481f3d3b95a5343139665',1,'example_rtc_wakeup.c']]]
];
