var searchData=
[
  ['_5f_5flow_5flevel_5finit_4463',['__low_level_init',['../aps__init_8c.html#ac11843d93e41358f2d964f1bf2c94a1e',1,'aps_init.c']]],
  ['_5fsbrk_4464',['_sbrk',['../syscalls_8c.html#a38f8394eee3a086b87ff6d431e1e5343',1,'syscalls.c']]],
  ['_5fwrite_4465',['_write',['../syscalls_8c.html#aa025a12d45f60c7d0eae249e61f0c7f9',1,'syscalls.c']]]
];
