var searchData=
[
  ['sys_5fctrl_5freg_2eh_4460',['sys_ctrl_reg.h',['../sys__ctrl__reg_8h.html',1,'']]],
  ['syscalls_2ec_4461',['syscalls.c',['../syscalls_8c.html',1,'']]]
];
