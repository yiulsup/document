var searchData=
[
  ['heatmap_5fconfig_5fmagic_5fnumber_6108',['HEATMAP_CONFIG_MAGIC_NUMBER',['../acc__heatmap__capon__config__structs_8h.html#a8d540de4f03f39b2570acc6ae4c2f97d',1,'HEATMAP_CONFIG_MAGIC_NUMBER():&#160;acc_heatmap_capon_config_structs.h'],['../acc__heatmap__conventional__config__structs_8h.html#a8d540de4f03f39b2570acc6ae4c2f97d',1,'HEATMAP_CONFIG_MAGIC_NUMBER():&#160;acc_heatmap_conventional_config_structs.h']]],
  ['heatmap_5fsubsweep_5fidx_6109',['HEATMAP_SUBSWEEP_IDX',['../example__heatmap__capon_8c.html#a15cdf318aab74cbebd58883d063774ee',1,'example_heatmap_capon.c']]]
];
