var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvwxyz",
  1: "_acdegimprsuw",
  2: "acegirsw",
  3: "_acdegilmprstuvw",
  4: "_abcdefghilmnoprstuwxyz",
  5: "afgrsuw",
  6: "a",
  7: "a",
  8: "acdeghilmnprstuw",
  9: "cdprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules"
};

