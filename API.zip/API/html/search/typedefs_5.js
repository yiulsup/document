var searchData=
[
  ['uart_5fhandle_5ftypedef_5ft_5318',['uart_handle_typedef_t',['../aps__uart_8h.html#ac2f86cbe67340a3689f58a37d8d6d107',1,'aps_uart.h']]]
];
