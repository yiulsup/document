var searchData=
[
  ['validate_5fheatmap_5fcapon_5fconfig_4173',['validate_heatmap_capon_config',['../acc__heatmap__capon_8c.html#aad7ba1972f2a384e2c6f601a187a34f6',1,'acc_heatmap_capon.c']]],
  ['validate_5fheatmap_5fconventional_5fconfig_4174',['validate_heatmap_conventional_config',['../acc__heatmap__conventional_8c.html#a817c64b5e5d41bdb7d5baacf21fcdbb8',1,'acc_heatmap_conventional.c']]],
  ['verify_5fcrc32_4175',['verify_crc32',['../acc__a2__dfu__spi__protocol_8c.html#a9d816aee701dd67daa8b314b242ecce9',1,'acc_a2_dfu_spi_protocol.c']]]
];
