var searchData=
[
  ['send_5fcommand_5fread_5fresponse_4924',['send_command_read_response',['../acc__a2__dfu__spi__bootstrap_8c.html#ad1ec1e7ce50302b4381d546b583d38ea',1,'acc_a2_dfu_spi_bootstrap.c']]],
  ['set_5fbaudrate_4925',['set_baudrate',['../acc__exploration__server_8c.html#adf0883296cbd94ad64fa10d1b47b8362',1,'acc_exploration_server.c']]],
  ['set_5fconfig_4926',['set_config',['../acc__noise__normalization_8c.html#a691e0a8955fd88c6d46d4fc346a08035',1,'set_config(acc_config_t *config, uint16_t num_points, config_backup_t *config_backup):&#160;acc_noise_normalization.c'],['../example__self__test_8c.html#a41c8618b4f7bae88ee4b4a8c35e306b2',1,'set_config(acc_config_t *config):&#160;example_self_test.c'],['../example__service__iq__double__buffering_8c.html#a41c8618b4f7bae88ee4b4a8c35e306b2',1,'set_config(acc_config_t *config):&#160;example_service_iq_double_buffering.c'],['../example__heatmap__capon_8c.html#a58ca26bce1f6bc6e8403a8830b6e917c',1,'set_config(acc_config_t *radar_config, acc_heatmap_capon_config_t *heatmap_config):&#160;example_heatmap_capon.c'],['../example__heatmap__conventional_8c.html#a8a242dc9b1bdbcb046a9f7436c44f4e9',1,'set_config(acc_config_t *radar_config, acc_heatmap_conventional_config_t *heatmap_config):&#160;example_heatmap_conventional.c'],['../example__service__iq_8c.html#a41c8618b4f7bae88ee4b4a8c35e306b2',1,'set_config(acc_config_t *config):&#160;example_service_iq.c'],['../example__service__iq__polling_8c.html#a41c8618b4f7bae88ee4b4a8c35e306b2',1,'set_config(acc_config_t *config):&#160;example_service_iq_polling.c']]],
  ['slv_5fcmd_5fcallback_4927',['slv_cmd_callback',['../acc__exploration__server_8c.html#a9417a35bcf6e84a8e6b0f231f79fd023',1,'acc_exploration_server.c']]],
  ['spi0_5fintr_4928',['spi0_intr',['../aps__spi__slave_8c.html#a276c50e7c4386530d5e12a616098d1f4',1,'aps_spi_slave.c']]],
  ['spi_5fdma_5fto_5fclient_4929',['spi_dma_to_client',['../acc__exploration__server_8c.html#a138578a946a7afa9a4607dd07b6604f2',1,'acc_exploration_server.c']]],
  ['spi_5fenable_5finterrupt_5fend_5ftransfer_4930',['spi_enable_interrupt_end_transfer',['../aps__spi__slave_8c.html#a6565ed9af5d713687e217e9ed08374f6',1,'aps_spi_slave.c']]],
  ['spi_5fenable_5finterrupt_5fslave_5fcmd_4931',['spi_enable_interrupt_slave_cmd',['../aps__spi__slave_8c.html#a8f056381f52d3f46dea61cd4307e1fc2',1,'aps_spi_slave.c']]],
  ['spi_5fsetup_5frx_5fdma_4932',['spi_setup_rx_dma',['../aps__spi__slave_8c.html#ab0e292c52b4b185e95a308fbd845eb3c',1,'aps_spi_slave.c']]],
  ['spi_5fsetup_5fslave_4933',['spi_setup_slave',['../aps__spi__slave_8c.html#a52c7f67883172d274c5372b985ecf8de',1,'aps_spi_slave.c']]],
  ['spi_5fsetup_5ftx_5fdma_4934',['spi_setup_tx_dma',['../aps__spi__slave_8c.html#a5ea2f3c4fedc9928a1b75e7e7e0f1870',1,'aps_spi_slave.c']]],
  ['spi_5fslave_5fready_5fset_4935',['spi_slave_ready_set',['../aps__spi__slave_8c.html#a3ba3f1f7336cbc25be4c213e424ce05e',1,'aps_spi_slave.c']]],
  ['spi_5fslave_5fstatus_5fuser_5fstatus_5fset_4936',['spi_slave_status_user_status_set',['../aps__spi__slave_8c.html#aad0eda3573840d6227bc0b55e25d7863',1,'aps_spi_slave.c']]],
  ['spi_5fwait_5finactive_4937',['spi_wait_inactive',['../aps__spi__slave_8c.html#a6058cfb15f1f7a8a25c7d91bc80304be',1,'aps_spi_slave.c']]],
  ['spi_5fwait_5ftx_5fempty_4938',['spi_wait_tx_empty',['../aps__spi__slave_8c.html#a3a90a968b016f866d768421488c8282b',1,'aps_spi_slave.c']]],
  ['start_5fsystick_4939',['start_systick',['../aps__system__tick_8c.html#a30ac7e2d1ff8422df7239e02fb109b23',1,'aps_system_tick.c']]]
];
