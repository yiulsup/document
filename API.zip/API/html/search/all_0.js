var searchData=
[
  ['_5f_5fheapbase_0',['__HeapBase',['../syscalls_8c.html#a0d316bd4ef5a593400435781c6c68b1c',1,'syscalls.c']]],
  ['_5f_5fheaplimit_1',['__HeapLimit',['../syscalls_8c.html#a4ee99e498d365d260fd876fab3a347c1',1,'syscalls.c']]],
  ['_5f_5flow_5flevel_5finit_2',['__low_level_init',['../aps__init_8c.html#ac11843d93e41358f2d964f1bf2c94a1e',1,'aps_init.c']]],
  ['_5f_5fspi_5fslave_5fhandle_5ftypedef_3',['__spi_slave_handle_typedef',['../struct____spi__slave__handle__typedef.html',1,'']]],
  ['_5f_5fuart_5fhandle_5ftypedef_4',['__uart_handle_typedef',['../struct____uart__handle__typedef.html',1,'']]],
  ['_5fsbrk_5',['_sbrk',['../syscalls_8c.html#a38f8394eee3a086b87ff6d431e1e5343',1,'syscalls.c']]],
  ['_5fstart_6',['_start',['../example__rtc__wakeup_8c.html#aaae9c5608af481f3d3b95a5343139665',1,'example_rtc_wakeup.c']]],
  ['_5fwrite_7',['_write',['../syscalls_8c.html#aa025a12d45f60c7d0eae249e61f0c7f9',1,'syscalls.c']]]
];
