var searchData=
[
  ['saved_5fcontext_4341',['SAVED_CONTEXT',['../structSAVED__CONTEXT.html',1,'']]],
  ['spi_5fregtype_4342',['SPI_RegType',['../structSPI__RegType.html',1,'']]],
  ['sys_5fctrl_5fregisters_5ft_4343',['sys_ctrl_registers_t',['../structsys__ctrl__registers__t.html',1,'']]]
];
