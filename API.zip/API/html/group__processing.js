var group__processing =
[
    [ "acc_processing_iq_result_t", "structacc__processing__iq__result__t.html", [
      [ "actual_sweep_rate", "structacc__processing__iq__result__t.html#afd158ce328c9b2b4c19d8f1ea683a971", null ],
      [ "calibration_needed", "structacc__processing__iq__result__t.html#a8c14b2e282701570960ed7d426a1446b", null ],
      [ "calibration_temperature", "structacc__processing__iq__result__t.html#a747e90e556bc4e5d1c5ea2e403de2e95", null ],
      [ "data_saturated", "structacc__processing__iq__result__t.html#a36a8fde06bd8174c1d25719d507a8810", null ],
      [ "frame", "structacc__processing__iq__result__t.html#a0298cd9f1b2003d14c4640991ea69bbb", null ],
      [ "temperature", "structacc__processing__iq__result__t.html#aa2132dcf115870f29d5de78479fce1b7", null ]
    ] ],
    [ "acc_processing_handle_t", "group__processing.html#gab6a6872392764176eb98ab0b5f239a7b", null ],
    [ "acc_processing_create", "group__processing.html#gaac59d72b7b8074a935e1b40b576dc524", null ],
    [ "acc_processing_destroy", "group__processing.html#gae4de89cf30aed273fe60506b045e8da5", null ],
    [ "acc_processing_get_hwaas_at_distance_point", "group__processing.html#gaab5c93bb5b1d5bff7c2b115b64d94e00", null ],
    [ "acc_processing_iq", "group__processing.html#ga45597323b52b5f87810173c176aef327", null ]
];