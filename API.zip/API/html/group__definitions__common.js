var group__definitions__common =
[
    [ "PRIsensor_id", "group__definitions__common.html#gae2ddc82b4481619b79cd8cafe9e43836", null ],
    [ "acc_sensor_id_t", "group__definitions__common.html#ga7af0e4bb3660c7c6843354709751178b", null ]
];