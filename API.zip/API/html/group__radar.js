var group__radar =
[
    [ "acc_radar_calibrate", "group__radar.html#ga5daa63937370da3244d894857a9397f5", null ],
    [ "acc_radar_get", "group__radar.html#gae2e5d57312d3027f4d299cebf0bf8876", null ],
    [ "acc_radar_get_calibration_temperature", "group__radar.html#ga7754658588cd0259946198d12aa6e063", null ],
    [ "acc_radar_handle_interrupt", "group__radar.html#ga5052704233d9d957cbb21ca14b407ec9", null ],
    [ "acc_radar_id_get", "group__radar.html#ga92142e87d5cdc1ecad0cbe47406c02c4", null ],
    [ "acc_radar_is_calibration_valid", "group__radar.html#ga20f020b92eefe27f0ddcbf24bc8b5011", null ],
    [ "acc_radar_measure", "group__radar.html#gab46569cdb79e1197b31580c18d3d4fbc", null ],
    [ "acc_radar_poll", "group__radar.html#gaf729f0b46501383d49fd57f092c83f2e", null ],
    [ "acc_radar_power_off", "group__radar.html#ga0a5a7a0e332fc799268eb6cdb107b089", null ],
    [ "acc_radar_power_on", "group__radar.html#ga7070bebbfe14f7f41fde63a4bc3d8089", null ],
    [ "acc_radar_prepare", "group__radar.html#gadb07ddbcad7451c2e194db18a46429df", null ],
    [ "acc_radar_wait", "group__radar.html#gaebeeeb458bcab8eb6b49ce84b2dfe9a5", null ]
];