var group__definitions =
[
    [ "acc_cal_result_t", "structacc__cal__result__t.html", [
      [ "data", "structacc__cal__result__t.html#a6d6f68b375da17fb747a9704e08f7836", null ]
    ] ],
    [ "acc_int16_complex_t", "structacc__int16__complex__t.html", [
      [ "imag", "structacc__int16__complex__t.html#abf752ab60679b63de25256a49205f081", null ],
      [ "real", "structacc__int16__complex__t.html#a216b6f50470c8dc2b1b219fa0cb31ff7", null ]
    ] ],
    [ "ACC_CAL_RESULT_DATA_SIZE", "group__definitions.html#ga45583a87484e0c099ad0d393a4d8b316", null ],
    [ "ACC_RADAR_ID_LENGTH", "group__definitions.html#gaa3ab22661bac1bc9b35afff2eb74544d", null ],
    [ "ACC_RX_ANTENNA_MASK_0", "group__definitions.html#ga1068728dad324ff542d6eda6b1064dbe", null ],
    [ "ACC_RX_ANTENNA_MASK_1", "group__definitions.html#ga065dc093b8db29a943b48ce90381db41", null ],
    [ "ACC_RX_ANTENNA_MASK_2", "group__definitions.html#gab5261a636c4dad93a859089c72b83a7c", null ],
    [ "ACC_RX_ANTENNA_MASK_3", "group__definitions.html#ga307b0d361e5043ecb403ee393830064b", null ],
    [ "ACC_TX_ANTENNA_MASK_0", "group__definitions.html#ga67e0d21934775d04640d249dce3f8ecb", null ],
    [ "ACC_TX_ANTENNA_MASK_1", "group__definitions.html#gabd91ce7e4c6e59f0b03b3bcb788d2418", null ],
    [ "ACC_TX_ANTENNA_MASK_2", "group__definitions.html#ga38e2c93649a16771c8751f08cb33cec1", null ],
    [ "acc_measure_result_t", "group__definitions.html#ga0e89fab8910a7692702fb2cc24274db8", null ],
    [ "float32_t", "group__definitions.html#ga4611b605e45ab401f02cab15c5e38715", null ],
    [ "acc_log_level_t", "group__definitions.html#ga2a574f003da6440aa63faaaf9dc6a906", [
      [ "ACC_LOG_LEVEL_ERROR", "group__definitions.html#gga2a574f003da6440aa63faaaf9dc6a906a4d3bfb21ceea033ad27e5713dca4cf38", null ],
      [ "ACC_LOG_LEVEL_WARNING", "group__definitions.html#gga2a574f003da6440aa63faaaf9dc6a906a6d7c13a9dae368a1ccc5d46774631ac7", null ],
      [ "ACC_LOG_LEVEL_INFO", "group__definitions.html#gga2a574f003da6440aa63faaaf9dc6a906a041f0b15b66773dd5ca02e3a5dff5278", null ],
      [ "ACC_LOG_LEVEL_VERBOSE", "group__definitions.html#gga2a574f003da6440aa63faaaf9dc6a906a3d38353a57c62d4ee3d8553ab4e4cb71", null ],
      [ "ACC_LOG_LEVEL_DEBUG", "group__definitions.html#gga2a574f003da6440aa63faaaf9dc6a906af804954572982b7789f6d47e9c347b93", null ]
    ] ],
    [ "acc_bitcount", "group__definitions.html#ga83e661edc59984eb5eb01215cf3168eb", null ]
];