var group__diagnostics =
[
    [ "acc_diagnostics_norm_dist_t", "structacc__diagnostics__norm__dist__t.html", [
      [ "mean", "structacc__diagnostics__norm__dist__t.html#afd934c1ae906bd49cea3ae64b6e93dff", null ],
      [ "stddev", "structacc__diagnostics__norm__dist__t.html#ad84a11bf8ee6843e50d36a4684153eba", null ]
    ] ],
    [ "acc_diagnostics_t", "structacc__diagnostics__t.html", [
      [ "adc", "structacc__diagnostics__t.html#a4fff98c4dd422f222f018e8a80d88b3d", null ],
      [ "aon", "structacc__diagnostics__t.html#aba9ecd2005c41149f2b2231b57e75e2e", null ],
      [ "aps", "structacc__diagnostics__t.html#a7d4f13cb02b4b66971d9370af51c1cf5", null ],
      [ "calibration", "structacc__diagnostics__t.html#a382a33ef2a815618d44dc7572962218d", null ],
      [ "ldo", "structacc__diagnostics__t.html#a2a2856718d1848782414a42bc692debd", null ],
      [ "length", "structacc__diagnostics__t.html#a1046a916fdd8eb6545ae816a6b3ba30d", null ],
      [ "noise", "structacc__diagnostics__t.html#a5f7bafe420d268305a6a4d78475ed712", null ],
      [ "package", "structacc__diagnostics__t.html#ae7d25f8012c7a1b9b28c678243fa441c", null ],
      [ "power_on_test", "structacc__diagnostics__t.html#af9583bc2e7f0a77e621b0b4a705395dd", null ],
      [ "ret2", "structacc__diagnostics__t.html#aa11eb23999bf554657e62fdbb6c9106d", null ],
      [ "ret3", "structacc__diagnostics__t.html#a26fa25d5ced0936b335401a60346ed1a", null ],
      [ "rs", "structacc__diagnostics__t.html#a6a1b0c3d650a7a4eba4db9301f8407e7", null ],
      [ "rs_pll_clk", "structacc__diagnostics__t.html#ad7acb7c819d36fc1532a8c96fc68b021", null ],
      [ "rs_pll_vco", "structacc__diagnostics__t.html#a3d176fc314b247851e133ac93821c97d", null ],
      [ "rtm", "structacc__diagnostics__t.html#a2d252db1903ad5946fda3232784a9863", null ],
      [ "rx_1", "structacc__diagnostics__t.html#a6326e64243994a3ccc4254e0937ed621", null ],
      [ "rx_2", "structacc__diagnostics__t.html#ae592822506713ae9b37ca9804d53ad44", null ],
      [ "rx_3", "structacc__diagnostics__t.html#ab85d4a1905f20427653efed925a26cae", null ],
      [ "rx_dig", "structacc__diagnostics__t.html#a28a044597c6208e49b611fdf3a00fa44", null ],
      [ "rx_rf", "structacc__diagnostics__t.html#a15d19d8484f2c492425fdf8ac209cd56", null ],
      [ "rx_rf_lo", "structacc__diagnostics__t.html#ada439dac7898edf38012bc7ce5e7b75a", null ],
      [ "signal", "structacc__diagnostics__t.html#a877b6e70f877648d5c94b058102908ac", null ],
      [ "snr", "structacc__diagnostics__t.html#afdc690b8922854ded86929446e12ad9f", null ],
      [ "snr_per_hwaas", "structacc__diagnostics__t.html#aae1ee8a52683f740164f930c6700a4ea", null ],
      [ "status", "structacc__diagnostics__t.html#aa75e81ba1938ee4fec9bad211ebbc973", null ],
      [ "tx_1v2", "structacc__diagnostics__t.html#a03946060d8b86e1f2487aaef7e06c030", null ],
      [ "tx_1v5", "structacc__diagnostics__t.html#affd434af1846bef853ad3525aa688440", null ],
      [ "wg_rx_1v2", "structacc__diagnostics__t.html#a52294efdc3f3d52e8f48286fb4d5a569", null ],
      [ "wg_rx_1v5", "structacc__diagnostics__t.html#a1a69b40be2f6d215b59571812c4b7f45", null ],
      [ "wg_tx_1v2", "structacc__diagnostics__t.html#a3b8b379a0dedeba52cc603765ee8723c", null ],
      [ "wg_tx_1v5", "structacc__diagnostics__t.html#a833bb4f30ee0ac82ce9c37a4612a0674", null ]
    ] ],
    [ "ACC_DIAGNOSTICS_MAX_NUM_CHANNELS", "group__diagnostics.html#ga55c9e26b55b1d2074bbd53a2a688e898", null ],
    [ "acc_diagnostics_handle_t", "group__diagnostics.html#ga2e311b17cfa95b2d61c5a6b9eb46ecbb", null ],
    [ "acc_diagnostics_package_t", "group__diagnostics.html#gaa8407aa20c3000d2949f3928e532f366", [
      [ "ACC_DIAGNOSTICS_PACKAGE_AP211", "group__diagnostics.html#ggaa8407aa20c3000d2949f3928e532f366a5fd0f1dcb88c354d06b416c3eef1c4a6", null ],
      [ "ACC_DIAGNOSTICS_PACKAGE_AP212", "group__diagnostics.html#ggaa8407aa20c3000d2949f3928e532f366a9db982386b17e12cec9d24089aeaba14", null ]
    ] ],
    [ "acc_diagnostics_status_t", "group__diagnostics.html#ga21c36d16941b481369ebcc92907fee9f", [
      [ "ACC_DIAGNOSTICS_STATUS_NOT_RUN", "group__diagnostics.html#gga21c36d16941b481369ebcc92907fee9fa86fa5edc3a1d342cea2658b20dd95aab", null ],
      [ "ACC_DIAGNOSTICS_STATUS_RUN", "group__diagnostics.html#gga21c36d16941b481369ebcc92907fee9fae6ccdccaccc7429886bd1d6e4339a895", null ],
      [ "ACC_DIAGNOSTICS_STATUS_SKIPPED", "group__diagnostics.html#gga21c36d16941b481369ebcc92907fee9fa72b359cc017d5b3252dbc05b4b583e1f", null ],
      [ "ACC_DIAGNOSTICS_STATUS_FAILED", "group__diagnostics.html#gga21c36d16941b481369ebcc92907fee9faee28d89a6098feaaa8645a3afa81f3e3", null ]
    ] ],
    [ "acc_diagnostics_handle_create", "group__diagnostics.html#ga33b9dc2a3e5b97ebfa1b9c668f684369", null ],
    [ "acc_diagnostics_handle_destroy", "group__diagnostics.html#gafb99ce73620bb50bc36befa059c60400", null ],
    [ "acc_diagnostics_report", "group__diagnostics.html#ga5336eb34ea14257ebd2d733964e9d257", null ],
    [ "acc_diagnostics_run", "group__diagnostics.html#gac5a725366ea78552dfab3903393c423b", null ]
];