var modules =
[
    [ "Definitions", "group__definitions.html", "group__definitions" ],
    [ "Definitions", "group__definitions__common.html", "group__definitions__common" ],
    [ "Diagnostics", "group__diagnostics.html", "group__diagnostics" ],
    [ "Service", "group__service.html", "group__service" ],
    [ "RSS", "group__rss.html", "group__rss" ]
];