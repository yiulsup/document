var group__rss =
[
    [ "acc_rss_get_buffer_size", "group__rss.html#ga1e5f8f4f392de0406ebaea77fe43d296", null ],
    [ "acc_rss_get_temperature", "group__rss.html#ga87c5127c1dbf3d7340e41b05ee72ff95", null ]
];